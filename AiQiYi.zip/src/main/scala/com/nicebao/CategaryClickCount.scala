package com.nicebao

/**
 * Created by IhaveBB on 2024/7/11 20:59
 * 保存在数据库的对象
 */
case class CategaryClickCount(day_categaryId:String,click_count:Int)
