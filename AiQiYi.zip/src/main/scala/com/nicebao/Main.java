package com.nicebao;

/**
 * Created by IhaveBB on 2024/7/11 16:06
 */
public class Main {
	public static void main(String[] args) {
		System.out.println("Hello world!");
	}
}