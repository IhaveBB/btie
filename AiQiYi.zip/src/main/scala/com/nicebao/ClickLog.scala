package com.nicebao

/**
 * Created by IhaveBB on 2024/7/11 20:47
 */
case class ClickLog(ip:String,time:String,categaryId:Int,refer:String,statusCode:Int)
